// Fill out your copyright notice in the Description page of Project Settings.


#include "DASlider.h"


void UDASlider::SynchronizeProperties() {
	Super::SynchronizeProperties();

	if (SliderStyle) {
		SetWidgetStyle(SliderStyle.GetDefaultObject()->Style);
	}
}
